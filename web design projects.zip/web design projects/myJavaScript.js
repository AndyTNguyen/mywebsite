document.querySelector(".navBar ul").style.cssText = " text-transform: uppercase; font-family: awesome";





//navbar close and open

var activateNav = function(){
	$('#hamburgerIcon').click(function(){
	$('.menu2').animate({
	left:'0px'
	},200);	
		
	$('body').animate({
	left:'20%'	
	},200)	
	
	});
	
	$('#closeIcon').click(function(){
		$('.menu2').animate({
			left:'-20%'
			},200)
		
	
		$('body').animate({
			left:'0px'
			},200)
	});
	
	
	$('.dropdown-projects').click(function(){
		$('.dropdown-menu').toggle();
		
	});
	
};

$(document).ready(activateNav);

// Description Box;

var postBox = function(){
	$('.btn').click(function(){
	var post = $('.status-box').val();
	$('<li>').text(post).prependTo('.post');
	$('.characterCounter').text(150);
	$('.status-box').val('');
	$('.btn').addClass('disabled');	
	})
	
$('.status-box').keyup(function(){
	var postLength = $(this).val().length;
	var charactersLeft = 150-postLength;
	$('.characterCounter').text(charactersLeft);
	
	if(charactersLeft < 0){
	$('.btn').addClass('disabled');	
	}
	else if(charactersLeft == 150){
	$('.btn').addClass('disabled');
	}
	else{
	$('.btn').removeClass('disabled');	
	}
});
	$('.btn').addClass('disabled');
 // changing count when user press delete   
$('.status-box').keydown(function(){
	var charactersLeft= postLength+1;
	if(charactersLeft > 150){
		charactersLeft = 150;	
	}
	
})
}
$(document).ready(postBox);
